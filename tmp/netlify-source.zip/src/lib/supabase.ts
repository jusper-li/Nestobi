import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type {
  UserAuth, MemberProfile, UserPreferences,
  Vendor, Property, Room, Booking,
  Category, Product, CartItem,
  Order, PurchaseRecord, Point,
  ItineraryPlan, Translation, ChatMessage,
  UserUsage, SuperAdmin, UserPermission, VerificationCode,
  StoreLocation, StoreLocationHours
} from '../types';
