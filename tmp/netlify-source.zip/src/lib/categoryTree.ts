export interface CategoryTreeItem {
  id: string;
  name: string;
  slug: string;
  parent_id: string | null;
  display_order?: number | null;
}

export interface CategoryLink {
  category_id: string | null;
}

export function sortCategoriesForTree<T extends CategoryTreeItem>(categories: T[]) {
  const byParent = new Map<string, T[]>();
  const roots: T[] = [];

  for (const category of categories) {
    if (category.parent_id) {
      const siblings = byParent.get(category.parent_id) || [];
      siblings.push(category);
      byParent.set(category.parent_id, siblings);
    } else {
      roots.push(category);
    }
  }

  const sortItems = (items: T[]) => items.sort((a, b) => {
    const orderA = typeof a.display_order === 'number' ? a.display_order : Number.MAX_SAFE_INTEGER;
    const orderB = typeof b.display_order === 'number' ? b.display_order : Number.MAX_SAFE_INTEGER;
    if (orderA !== orderB) return orderA - orderB;
    return a.name.localeCompare(b.name, 'zh-Hant');
  });
  const ordered: T[] = [];

  const visit = (category: T) => {
    ordered.push(category);
    for (const child of sortItems(byParent.get(category.id) || [])) visit(child);
  };

  for (const root of sortItems(roots)) visit(root);
  return ordered;
}

export function getCategoryDepth(category: CategoryTreeItem, categories: CategoryTreeItem[]) {
  const byId = new Map(categories.map(item => [item.id, item]));
  let depth = 0;
  let current = category;

  while (current.parent_id && byId.has(current.parent_id) && depth < 8) {
    depth += 1;
    current = byId.get(current.parent_id)!;
  }

  return depth;
}

export function getCategoryPath(category: CategoryTreeItem, categories: CategoryTreeItem[]) {
  const byId = new Map(categories.map(item => [item.id, item]));
  const path = [category.name];
  let current = category;

  while (current.parent_id && byId.has(current.parent_id) && path.length < 8) {
    current = byId.get(current.parent_id)!;
    path.unshift(current.name);
  }

  return path.join(' / ');
}

export function getCategoryOptionLabel(category: CategoryTreeItem, categories: CategoryTreeItem[]) {
  const depth = getCategoryDepth(category, categories);
  return `${'  '.repeat(depth)}${depth > 0 ? '- ' : ''}${category.name}`;
}

export function getDescendantCategoryIds(categories: CategoryTreeItem[], selectedId: string) {
  const ids = new Set([selectedId]);
  let changed = true;

  while (changed) {
    changed = false;
    for (const category of categories) {
      if (category.parent_id && ids.has(category.parent_id) && !ids.has(category.id)) {
        ids.add(category.id);
        changed = true;
      }
    }
  }

  return ids;
}

export function getProductCategoryIds(product: { category_id?: string | null; product_category_links?: CategoryLink[] | null }) {
  const ids = new Set<string>();
  if (product.category_id) ids.add(product.category_id);

  for (const link of product.product_category_links || []) {
    if (link.category_id) ids.add(link.category_id);
  }

  return ids;
}

export function getBlogPostCategoryIds(post: { blog_post_category_links?: CategoryLink[] | null }) {
  const ids = new Set<string>();

  for (const link of post.blog_post_category_links || []) {
    if (link.category_id) ids.add(link.category_id);
  }

  return ids;
}
