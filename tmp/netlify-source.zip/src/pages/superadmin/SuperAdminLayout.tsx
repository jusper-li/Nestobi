import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Shield, LogOut, Menu, Crown, Users, Store, BarChart2, BedDouble, ShoppingBag, Package, Brain, MessageSquare, FileText, Settings, HelpCircle, Terminal, Coffee, FolderOpen, MapPin } from 'lucide-react';
import { Tags } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const navLinks = [
  { to: '/superadmin/product-categories', icon: <Tags className="w-5 h-5" />, label: '商品分類' },
  { to: '/superadmin/store-locations', icon: <MapPin className="w-5 h-5" />, label: '門市據點' },
  { to: '/superadmin', icon: <LayoutDashboard className="w-5 h-5" />, label: '系統總覽', end: true },
  { to: '/superadmin/users', icon: <Users className="w-5 h-5" />, label: '用戶管理' },
  { to: '/superadmin/vendors', icon: <Store className="w-5 h-5" />, label: '廠商管理' },
  { to: '/superadmin/rooms', icon: <BedDouble className="w-5 h-5" />, label: '所有房間' },
  { to: '/superadmin/products', icon: <ShoppingBag className="w-5 h-5" />, label: '所有商品' },
  { to: '/superadmin/orders', icon: <Package className="w-5 h-5" />, label: '訂單數據' },
  { to: '/superadmin/revenue', icon: <BarChart2 className="w-5 h-5" />, label: '營收報表' },
  { to: '/superadmin/blog', icon: <Coffee className="w-5 h-5" />, label: '文章管理' },
  { to: '/superadmin/blog-categories', icon: <FolderOpen className="w-5 h-5" />, label: '文章分類' },
  { to: '/superadmin/ai-analytics', icon: <Brain className="w-5 h-5" />, label: 'AI 用量分析' },
  { to: '/superadmin/chatbot', icon: <MessageSquare className="w-5 h-5" />, label: 'AI 客服紀錄' },
  { to: '/superadmin/static-pages', icon: <FileText className="w-5 h-5" />, label: '靜態頁面' },
  { to: '/superadmin/permissions', icon: <Shield className="w-5 h-5" />, label: '權限設定' },
  { to: '/superadmin/faq', icon: <HelpCircle className="w-5 h-5" />, label: '常見問題' },
  { to: '/superadmin/site-settings', icon: <Settings className="w-5 h-5" />, label: '網站設定' },
  { to: '/superadmin/listing-command', icon: <Terminal className="w-5 h-5" />, label: 'AI 上架指令' },
];

const SuperAdminLayout: React.FC = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  const { signOut } = useAuth();
  const doSignOut = async () => { await signOut(); navigate('/auth/login'); };

  const Sidebar = () => (
    <div className="flex flex-col h-full">
      <div className="p-5 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-400 rounded-xl flex items-center justify-center">
            <Crown className="w-6 h-6 text-slate-900" />
          </div>
          <div>
            <p className="font-bold text-white text-sm">超級管理後台</p>
            <span className="text-xs bg-amber-400 text-slate-900 px-1.5 py-0.5 rounded font-bold">SUPERADMIN</span>
          </div>
        </div>
      </div>
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {navLinks.map(link => (
          <NavLink key={link.to} to={link.to} end={link.end} onClick={() => setSidebarOpen(false)}
            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${isActive ? 'bg-amber-500 text-slate-900' : 'text-slate-300 hover:text-white hover:bg-slate-700'}`}>
            {link.icon}{link.label}
          </NavLink>
        ))}
      </nav>
      <div className="p-3 border-t border-slate-800">
        <p className="text-slate-400 text-xs px-3 mb-2 truncate">{user?.email}</p>
        <button onClick={doSignOut} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-400 hover:bg-slate-700 w-full transition">
          <LogOut className="w-5 h-5" />登出
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <aside className="hidden md:block w-64 bg-slate-900 h-screen sticky top-0 flex-shrink-0">
        <Sidebar />
      </aside>
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="absolute left-0 top-0 h-full w-64 bg-slate-900 z-50"><Sidebar /></div>
        </div>
      )}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden bg-slate-900 px-4 py-3 flex items-center gap-3 sticky top-0 z-40">
          <button onClick={() => setSidebarOpen(true)} className="p-2 hover:bg-slate-800 rounded-lg"><Menu className="w-5 h-5 text-white" /></button>
          <span className="font-semibold text-white">超級管理後台</span>
        </header>
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default SuperAdminLayout;
